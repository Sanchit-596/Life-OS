// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Returns an array of Date objects for every day from today up to (and including) deadlineStr. */
function daysBetweenTodayAndDeadline(deadlineStr) {
  const days = [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const deadline = new Date(deadlineStr);
  deadline.setHours(0, 0, 0, 0);

  const cursor = new Date(today);
  while (cursor <= deadline) {
    days.push(new Date(cursor));
    cursor.setDate(cursor.getDate() + 1);
  }
  return days;
}

/** Maps a JS getDay() index (0=Sun … 6=Sat) to the hoursAvailablePerDay key. */
const DAY_INDEX_TO_KEY = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

/**
 * Sums available hours between today and a deadline, optionally applying a
 * hypothetical change that reduces availability on one specific day-of-week.
 */
function sumAvailableHours(deadlineStr, hoursAvailablePerDay, hypotheticalChange) {
  const days = daysBetweenTodayAndDeadline(deadlineStr);
  let total = 0;

  for (const day of days) {
    const key = DAY_INDEX_TO_KEY[day.getDay()];
    let dayHours = hoursAvailablePerDay[key] ?? 0;

    if (
      hypotheticalChange &&
      hypotheticalChange.type === "reduceAvailability" &&
      hypotheticalChange.day === key
    ) {
      dayHours = Math.max(0, dayHours - (hypotheticalChange.hoursRemoved ?? 0));
    }

    total += dayHours;
  }

  return total;
}

// ─── Core ─────────────────────────────────────────────────────────────────────

/**
 * runSimulation — pure function, no side effects.
 *
 * @param {Array}  tasks               Array of task objects (see data.js schema).
 * @param {Object} hoursAvailablePerDay Map of { Mon, Tue, Wed, Thu, Fri, Sat, Sun } → number.
 * @param {Object} [hypotheticalChange] Optional scenario modifier:
 *   {
 *     type:         "reduceAvailability",
 *     day:          "Sat",          // day-of-week key
 *     hoursRemoved: 6,              // hours to subtract from that day
 *     reason:       "string"        // human-readable description
 *   }
 *
 * @returns {{
 *   conflicts:          Array<{ taskId, title, hoursNeeded, hoursAvailable, deficitHours, deadline }>,
 *   slackHours:         number,
 *   totalHoursNeeded:   number,
 *   totalHoursAvailable:number,
 *   isFeasible:         boolean
 * }}
 */
function runSimulation(tasks, hoursAvailablePerDay, hypotheticalChange) {
  const pendingTasks = tasks.filter((t) => t.status === "pending" || t.status === "in-progress");

  let totalHoursNeeded = 0;
  let totalHoursAvailable = 0;
  const conflicts = [];

  for (const task of pendingTasks) {
    const hoursNeeded = task.estimatedHours;
    const hoursAvailable = sumAvailableHours(task.deadline, hoursAvailablePerDay, hypotheticalChange);

    totalHoursNeeded += hoursNeeded;
    totalHoursAvailable += hoursAvailable;

    if (hoursNeeded > hoursAvailable) {
      conflicts.push({
        taskId: task.id,
        title: task.title,
        hoursNeeded,
        hoursAvailable,
        deficitHours: +(hoursNeeded - hoursAvailable).toFixed(2),
        deadline: task.deadline,
      });
    }
  }

  const slackHours = +(totalHoursAvailable - totalHoursNeeded).toFixed(2);

  return {
    conflicts,
    slackHours,
    totalHoursNeeded: +totalHoursNeeded.toFixed(2),
    totalHoursAvailable: +totalHoursAvailable.toFixed(2),
    isFeasible: conflicts.length === 0,
  };
}

// ─── Test cases ───────────────────────────────────────────────────────────────

if (typeof require !== "undefined") {
  // In a real browser environment this guard would be removed.
  const WEEKLY = { Mon: 4, Tue: 3, Wed: 3, Thu: 2, Fri: 3, Sat: 0, Sun: 5 };

  // Helper: builds a deadline N days from today.
  function daysFromToday(n) {
    const d = new Date();
    d.setDate(d.getDate() + n);
    return d.toISOString().slice(0, 10);
  }

  // ── Test 1: plenty of slack ────────────────────────────────────────────────
  console.log("\n=== Test 1: Plenty of slack ===");
  const tasks1 = [
    { id: "t1", title: "Read textbook chapter", deadline: daysFromToday(30), estimatedHours: 3, status: "pending" },
    { id: "t2", title: "Short quiz prep",       deadline: daysFromToday(14), estimatedHours: 2, status: "pending" },
  ];
  console.log(runSimulation(tasks1, WEEKLY, null));
  // Expected: no conflicts, positive slackHours, isFeasible = true

  // ── Test 2: exactly one conflict ──────────────────────────────────────────
  console.log("\n=== Test 2: One conflict ===");
  const tasks2 = [
    { id: "t3", title: "Hackathon MVP (tight deadline)", deadline: daysFromToday(1), estimatedHours: 20, status: "in-progress" },
    { id: "t4", title: "Grocery shopping",               deadline: daysFromToday(5), estimatedHours: 1,  status: "pending" },
  ];
  console.log(runSimulation(tasks2, WEEKLY, null));
  // Expected: 1 conflict for t3, isFeasible = false

  // ── Test 3: multiple conflicts (hypothetical change applied) ──────────────
  console.log("\n=== Test 3: Multiple conflicts with hypothetical change ===");
  const tasks3 = [
    { id: "t5", title: "Thesis chapter draft",    deadline: daysFromToday(3), estimatedHours: 15, status: "pending" },
    { id: "t6", title: "Algorithms problem set",  deadline: daysFromToday(2), estimatedHours: 10, status: "pending" },
    { id: "t7", title: "Side project feature",    deadline: daysFromToday(4), estimatedHours: 12, status: "in-progress" },
  ];
  const change3 = {
    type: "reduceAvailability",
    day: "Mon",
    hoursRemoved: 4,
    reason: "Unexpected family commitment on Monday",
  };
  console.log(runSimulation(tasks3, WEEKLY, change3));
  // Expected: 2–3 conflicts, isFeasible = false, negative slackHours

  // ── Test 4: empty task list ────────────────────────────────────────────────
  console.log("\n=== Test 4: Empty task list ===");
  console.log(runSimulation([], WEEKLY, null));
  // Expected: { conflicts: [], slackHours: 0, totalHoursNeeded: 0, totalHoursAvailable: 0, isFeasible: true }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

if (typeof module !== "undefined" && module.exports) {
  module.exports = { runSimulation };
}
