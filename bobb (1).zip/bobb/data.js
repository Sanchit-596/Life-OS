// ─── Storage ────────────────────────────────────────────────────────────────

const STORAGE_KEY = "lifeos_tasks";

function loadTasks() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveTasks(tasks) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

// ─── Task factory ────────────────────────────────────────────────────────────

/**
 * taskData shape:
 *   title         {string}
 *   deadline      {string}  ISO date, e.g. "2025-08-10"
 *   estimatedHours {number}
 *   priority      {1|2|3}   1 = high, 2 = medium, 3 = low
 *   category      {string}  e.g. "academic" | "hackathon" | "personal"
 *   status        {string}  "pending" | "in-progress" | "done"
 */
function addTask(taskData) {
  const tasks = loadTasks();

  const newTask = {
    id: `task_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    title: taskData.title,
    deadline: taskData.deadline,
    estimatedHours: taskData.estimatedHours,
    priority: taskData.priority,
    category: taskData.category,
    status: taskData.status ?? "pending",
  };

  tasks.push(newTask);
  saveTasks(tasks);
  return newTask;
}

// ─── Availability ────────────────────────────────────────────────────────────

function getWeeklyHoursAvailable() {
  return {
    Mon: 4,
    Tue: 3,
    Wed: 3,
    Thu: 2,
    Fri: 3,
    Sat: 0,
    Sun: 5,
  };
}

// ─── Seed data ───────────────────────────────────────────────────────────────

const SEED_TASKS = [
  {
    id: "seed_001",
    title: "Write literature review for CS thesis",
    deadline: "2025-08-15",
    estimatedHours: 18,
    priority: 1,
    category: "academic",
    status: "pending",
  },
  {
    id: "seed_002",
    title: "Build MVP for campus hackathon",
    deadline: "2025-07-28",
    estimatedHours: 24,
    priority: 1,
    category: "hackathon",
    status: "in-progress",
  },
  {
    id: "seed_003",
    title: "Complete algorithms problem set #4",
    deadline: "2025-07-22",
    estimatedHours: 6,
    priority: 2,
    category: "academic",
    status: "pending",
  },
  {
    id: "seed_004",
    title: "Prepare slide deck for project demo",
    deadline: "2025-07-30",
    estimatedHours: 5,
    priority: 2,
    category: "hackathon",
    status: "pending",
  },
  {
    id: "seed_005",
    title: "Read 'Deep Work' and take notes",
    deadline: "2025-08-31",
    estimatedHours: 8,
    priority: 3,
    category: "personal",
    status: "pending",
  },
];

// ─── Exports (Node / ESM-compatible guard) ───────────────────────────────────

if (typeof module !== "undefined" && module.exports) {
  module.exports = { loadTasks, saveTasks, addTask, getWeeklyHoursAvailable, SEED_TASKS };
}
